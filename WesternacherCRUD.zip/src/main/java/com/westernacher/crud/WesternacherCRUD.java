package com.westernacher.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.westernacher.crud.configuration.DBConfiguration;

/**
 *  Main class
 * @author User
 *
 */
@Import(DBConfiguration.class)
@SpringBootApplication(scanBasePackages={"com.westernacher.crud"})
public class WesternacherCRUD {

	public static void main(String[] args) {
		SpringApplication.run(WesternacherCRUD.class, args);
	}


}
