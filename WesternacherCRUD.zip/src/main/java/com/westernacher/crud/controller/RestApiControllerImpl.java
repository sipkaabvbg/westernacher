package com.westernacher.crud.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.westernacher.crud.api.RestApiControllerInterface;
import com.westernacher.crud.api.UserServiceInterface;
import com.westernacher.crud.model.User;
import com.westernacher.crud.util.CustomErrorType;

/**
 * Handling the REST API calls
 * @author User
 *
 */
@RestController
@RequestMapping("/api")
public class RestApiControllerImpl implements RestApiControllerInterface{

	public static final Logger logger = LoggerFactory.getLogger(RestApiControllerImpl.class);

	//Service which will do all data manipulation
	@Autowired
	UserServiceInterface userService; 

	/**
	 * Retrieve Single User
	 */ 
	public ResponseEntity<?> getUser(@PathVariable("id") long id) {
		logger.info("Fetching User with id {}", id);
		User user = userService.findById(id);
		if (user == null) {
			logger.error("User with id {} not found.", id);
			return new ResponseEntity(new CustomErrorType("User with id " + id 
					+ " not found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}

	/**
	 * Retrieve All Users
	 */
	public ResponseEntity<List<User>> listAllUsers() {
		List<User> users = userService.findAllUsers();
		if (users.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT); 
		}
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}
	
	/**
	 * Create a User
	 */
	public ResponseEntity<?> createUser(@RequestBody User user, UriComponentsBuilder ucBuilder) {
		logger.info("Creating User : {}", user);

		if (userService.isUserExist(user)) {
			logger.error("Unable to create user. A User with  Email Address {} already exist", user.getEmailAddress());
			return new ResponseEntity(new CustomErrorType("Unable to create user. A User with Email Address " + 
		   user.getEmailAddress() + " already exist."),HttpStatus.CONFLICT);
		}
		userService.saveUser(user);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/api/user/{id}").buildAndExpand(user.getId()).toUri());
		return new ResponseEntity<String>(headers, HttpStatus.CREATED);
	}

	/**
	 * Delete a User
	 */
	public ResponseEntity<?> deleteUser(@PathVariable("id") long id) {
		logger.info("Deleting User with id {}", id);

		User user = userService.findById(id);
		if (user == null) {
			logger.error("Unable to delete user with id {}, id not found!", id);
			return new ResponseEntity(new CustomErrorType("Unable to delete user with id " + id + ", id not found!"),
					HttpStatus.NOT_FOUND);
		}
		userService.deleteUserById(id);
		return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
	}
	
	/**
	 * Update a User
	 */
	public ResponseEntity<?> updateUser(@PathVariable("id") long id, @RequestBody User user) {
		logger.info("Updating User with id {}", id);

		User currentUser = userService.findById(id);

		if (currentUser == null) {
			logger.error("Unable to update user with id {}, id not found.", id);
			return new ResponseEntity(new CustomErrorType("Unable to upate user with id " + id + ", id not found."),
					HttpStatus.NOT_FOUND);
		}
		
		currentUser.setFirstName(user.getFirstName());
		currentUser.setLastName(user.getLastName());
		currentUser.setEmailAddress(user.getEmailAddress());
		currentUser.setBirthDate(user.getBirthDate());

		userService.updateUser(currentUser);
		return new ResponseEntity<User>(currentUser, HttpStatus.OK);
	}
	
	/**
	 * Delete All Users
	 */
	public ResponseEntity<User> deleteAllUsers() {
		logger.info("Deleting All Users");

		userService.deleteAllUsers();
		return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
	}

}