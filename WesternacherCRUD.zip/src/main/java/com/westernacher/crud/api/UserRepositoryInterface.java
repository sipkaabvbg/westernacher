package com.westernacher.crud.api;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.westernacher.crud.model.User;

/**
 * Spring Data repository
 * @author User
 *
 */
@Repository
public interface UserRepositoryInterface extends JpaRepository<User, Long> {

   public User findByEmailAddress(String emailAddress);

}
