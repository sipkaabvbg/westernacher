package com.westernacher.crud.api;


import java.util.List;

import com.westernacher.crud.model.User;

/**
 * Service for all user-related operations
 * @author User
 *
 */
public interface UserServiceInterface {
	
	public User findById(Long id);

	public User findByEmailAddress(String emailAddress);

	public void saveUser(User user);

	public void updateUser(User user);

	public void deleteUserById(Long id);

	public void deleteAllUsers();

	public List<User> findAllUsers();

	public boolean isUserExist(User user);
}